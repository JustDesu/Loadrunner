Action()
{
	lr_start_transaction("UC2_Delete");

		open_page();
	
		lr_think_time(5);
	
		login();
		
		lr_think_time(5);
	
		click_itinerary();
		
		lr_think_time(5);
	
		delete();
		
		lr_think_time(5);
	
		log_out();

	lr_end_transaction("UC2_Delete", LR_AUTO);

	return 0;
}