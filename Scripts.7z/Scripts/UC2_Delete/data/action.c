Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"http://localhost:1080");

	lr_think_time(5);

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=body", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=134921.145321993zQtAAAzptVcftVztApADitHf", ENDITEM, 
		"Name=username", "Value=Jotaro", ENDITEM, 
		"Name=password", "Value=Dio", ENDITEM, 
		"Name=login.x", "Value=0", ENDITEM, 
		"Name=login.y", "Value=0", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	lr_start_transaction("clickItinerary");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("Itinerary Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("clickItinerary",LR_AUTO);

	lr_start_transaction("chooseTicketForDelete");

	web_add_header("Origin", 
		"http://localhost:1080");

	lr_think_time(24);

	web_submit_data("itinerary.pl", 
		"Action=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=1", "Value=on", ENDITEM, 
		"Name=flightID", "Value=41148532-798-JK", ENDITEM, 
		"Name=flightID", "Value=41148532-1568-JK", ENDITEM, 
		"Name=flightID", "Value=41148539-2350-JK", ENDITEM, 
		"Name=flightID", "Value=41148539-3119-JK", ENDITEM, 
		"Name=flightID", "Value=41148574-3884-JK", ENDITEM, 
		"Name=flightID", "Value=41148539-4658-JK", ENDITEM, 
		"Name=flightID", "Value=41-5-JK", ENDITEM, 
		"Name=flightID", "Value=41-6-JU", ENDITEM, 
		"Name=flightID", "Value=41-6-IU", ENDITEM, 
		"Name=flightID", "Value=41148539-7735-JK", ENDITEM, 
		"Name=flightID", "Value=41148539-8504-JK", ENDITEM, 
		"Name=flightID", "Value=41-9-JK", ENDITEM, 
		"Name=flightID", "Value=41-10-JK", ENDITEM, 
		"Name=flightID", "Value=41-10-JK", ENDITEM, 
		"Name=flightID", "Value=41-11-JK", ENDITEM, 
		"Name=flightID", "Value=41-12-JK", ENDITEM, 
		"Name=flightID", "Value=41-13-JK", ENDITEM, 
		"Name=flightID", "Value=41-13-JK", ENDITEM, 
		"Name=flightID", "Value=41-14-JK", ENDITEM, 
		"Name=flightID", "Value=41-15-JK", ENDITEM, 
		"Name=flightID", "Value=41-16-JK", ENDITEM, 
		"Name=flightID", "Value=41-16-JK", ENDITEM, 
		"Name=flightID", "Value=41-17-JK", ENDITEM, 
		"Name=flightID", "Value=41-18-JK", ENDITEM, 
		"Name=flightID", "Value=0-19283-VV", ENDITEM, 
		"Name=flightID", "Value=0-20045-VV", ENDITEM, 
		"Name=flightID", "Value=0-20821-VU", ENDITEM, 
		"Name=flightID", "Value=0-21584-VV", ENDITEM, 
		"Name=flightID", "Value=0-22363-VU", ENDITEM, 
		"Name=flightID", "Value=0-23132-VV", ENDITEM, 
		"Name=flightID", "Value=0-23891-VU", ENDITEM, 
		"Name=flightID", "Value=0-24668-VV", ENDITEM, 
		"Name=flightID", "Value=0-25430-VU", ENDITEM, 
		"Name=flightID", "Value=0-26203-VV", ENDITEM, 
		"Name=flightID", "Value=0-26978-VV", ENDITEM, 
		"Name=flightID", "Value=41148651-27737-VV", ENDITEM, 
		"Name=removeFlights.x", "Value=65", ENDITEM, 
		"Name=removeFlights.y", "Value=9", ENDITEM, 
		"Name=.cgifields", "Value=33", ENDITEM, 
		"Name=.cgifields", "Value=32", ENDITEM, 
		"Name=.cgifields", "Value=21", ENDITEM, 
		"Name=.cgifields", "Value=7", ENDITEM, 
		"Name=.cgifields", "Value=26", ENDITEM, 
		"Name=.cgifields", "Value=17", ENDITEM, 
		"Name=.cgifields", "Value=2", ENDITEM, 
		"Name=.cgifields", "Value=1", ENDITEM, 
		"Name=.cgifields", "Value=18", ENDITEM, 
		"Name=.cgifields", "Value=30", ENDITEM, 
		"Name=.cgifields", "Value=16", ENDITEM, 
		"Name=.cgifields", "Value=27", ENDITEM, 
		"Name=.cgifields", "Value=25", ENDITEM, 
		"Name=.cgifields", "Value=28", ENDITEM, 
		"Name=.cgifields", "Value=20", ENDITEM, 
		"Name=.cgifields", "Value=14", ENDITEM, 
		"Name=.cgifields", "Value=24", ENDITEM, 
		"Name=.cgifields", "Value=10", ENDITEM, 
		"Name=.cgifields", "Value=31", ENDITEM, 
		"Name=.cgifields", "Value=35", ENDITEM, 
		"Name=.cgifields", "Value=11", ENDITEM, 
		"Name=.cgifields", "Value=22", ENDITEM, 
		"Name=.cgifields", "Value=13", ENDITEM, 
		"Name=.cgifields", "Value=23", ENDITEM, 
		"Name=.cgifields", "Value=29", ENDITEM, 
		"Name=.cgifields", "Value=6", ENDITEM, 
		"Name=.cgifields", "Value=36", ENDITEM, 
		"Name=.cgifields", "Value=3", ENDITEM, 
		"Name=.cgifields", "Value=9", ENDITEM, 
		"Name=.cgifields", "Value=12", ENDITEM, 
		"Name=.cgifields", "Value=15", ENDITEM, 
		"Name=.cgifields", "Value=8", ENDITEM, 
		"Name=.cgifields", "Value=4", ENDITEM, 
		"Name=.cgifields", "Value=34", ENDITEM, 
		"Name=.cgifields", "Value=19", ENDITEM, 
		"Name=.cgifields", "Value=5", ENDITEM, 
		LAST);

	lr_end_transaction("chooseTicketForDelete",LR_AUTO);

	lr_start_transaction("logOut");

	web_url("SignOff Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("logOut",LR_AUTO);

	return 0;
}