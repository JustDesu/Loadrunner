Action()
{
	lr_start_transaction("UC1_BuyTicket");

		open_page();
	
		lr_think_time(13);
	
		login();
		
		lr_think_time(5);
	
		click_flights();
		
		lr_think_time(43);
		
		click_find_flights();
	
		lr_think_time(35);
	
		choose_ticket();
	
		lr_think_time(29);
	
		fill_payment_details();
	
		lr_think_time(9);
	
		log_out();
	
	lr_end_transaction("UC1_BuyTicket", LR_AUTO);

	return 0;
}