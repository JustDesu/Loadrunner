Action()
{

	open_page();
	
	lr_think_time(18);

	login();
	
	lr_think_time(18);
	
	click_itinerary2();

	lr_think_time(9);
	
	deleteAll();

	lr_think_time(10);

	log_out();

	return 0;
}